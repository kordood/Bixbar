#나의 캡슐이 처리할 사용자의 말들

# 1. [목적]
# 사용자가 알고싶은 칵테일 추천해주기

# 2. [사용자가 입력할 말들]
#  레시피 알려줘
# 블랙러시안 보여줘
# 블랙러시안 알려줘

# 3. [발화함수 : Action]
# RecommandOperation

# 4. [발화 변수 : Input Concept]
# 블랙러시안 -> CocktailName
# 

# 5. [발화 변수 : Output Concept]
# Results

#### vocab을 어떻게 설정할지.

